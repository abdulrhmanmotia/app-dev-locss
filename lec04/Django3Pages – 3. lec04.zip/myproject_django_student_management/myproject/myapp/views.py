from django.shortcuts import render
from django.http import HttpResponse

# بيانات وهمية للطلاب
def get_students_data():
    """إرجاع بيانات الطلاب الوهمية"""
    students = [
        {
            'name': 'أحمد محمد العلي',
            'student_id': 'STU-2024-001',
            'college': 'كلية الهندسة',
            'level': 'السنة الثانية',
            'email': 'ahmed.ali@university.edu.sa',
            'courses': ['الرياضيات المتقدمة', 'الفيزياء الهندسية', 'البرمجة الأساسية', 'التصميم الهندسي']
        },
        {
            'name': 'فاطمة سعد الغامدي',
            'student_id': 'STU-2024-002',
            'college': 'كلية الطب',
            'level': 'السنة الأولى',
            'email': 'fatima.ghamdi@university.edu.sa',
            'courses': ['علم التشريح', 'الكيمياء الطبية', 'الأحياء الجزيئية', 'مقدمة في الطب']
        },
        {
            'name': 'محمد خالد القحطاني',
            'student_id': 'STU-2024-003',
            'college': 'كلية إدارة الأعمال',
            'level': 'السنة الثالثة',
            'email': 'mohammed.qahtani@university.edu.sa',
            'courses': ['المحاسبة المالية', 'إدارة التسويق', 'الاقتصاد الجزئي', 'ريادة الأعمال']
        },
        {
            'name': 'نورا عبدالرحمن الشهري',
            'student_id': 'STU-2024-004',
            'college': 'كلية العلوم',
            'level': 'السنة الثانية',
            'email': 'nora.shehri@university.edu.sa',
            'courses': ['الكيمياء العضوية', 'الفيزياء النظرية', 'الإحصاء التطبيقي', 'علوم الحاسوب']
        },
        {
            'name': 'عبدالله يوسف المطيري',
            'student_id': 'STU-2024-005',
            'college': 'كلية الآداب',
            'level': 'السنة الرابعة',
            'email': 'abdullah.mutairi@university.edu.sa',
            'courses': ['الأدب العربي المعاصر', 'علم النفس التربوي', 'فلسفة التاريخ', 'اللغويات التطبيقية']
        },
        {
            'name': 'سارة أحمد الدوسري',
            'student_id': 'STU-2024-006',
            'college': 'كلية التربية',
            'level': 'السنة الثانية',
            'email': 'sarah.dosari@university.edu.sa',
            'courses': ['علم النفس التربوي', 'طرق التدريس', 'تقنيات التعليم', 'الإرشاد الأكاديمي']
        },
        {
            'name': 'يوسف ماجد الحربي',
            'student_id': 'STU-2024-007',
            'college': 'كلية الحقوق',
            'level': 'السنة الثالثة',
            'email': 'yousef.harbi@university.edu.sa',
            'courses': ['القانون المدني', 'القانون الجنائي', 'القانون التجاري', 'أصول المحاكمات']
        },
        {
            'name': 'هند سلمان العتيبي',
            'student_id': 'STU-2024-008',
            'college': 'كلية الهندسة',
            'level': 'السنة الأولى',
            'email': 'hind.otaibi@university.edu.sa',
            'courses': ['الرياضيات الأساسية', 'الفيزياء العامة', 'الكيمياء الهندسية', 'مقدمة في الهندسة']
        },
        {
            'name': 'خالد عمر الزهراني',
            'student_id': 'STU-2024-009',
            'college': 'كلية الطب',
            'level': 'السنة الثالثة',
            'email': 'khalid.zahrani@university.edu.sa',
            'courses': ['علم الأمراض', 'الصيدلة السريرية', 'طب الأطفال', 'الجراحة العامة']
        },
        {
            'name': 'ريم فهد البقمي',
            'student_id': 'STU-2024-010',
            'college': 'كلية العلوم',
            'level': 'السنة الرابعة',
            'email': 'reem.baqami@university.edu.sa',
            'courses': ['الكيمياء التحليلية', 'علوم البيئة', 'البحوث العلمية', 'التطبيقات المعملية']
        },
        {
            'name': 'عبدالعزيز ناصر السبيعي',
            'student_id': 'STU-2024-011',
            'college': 'كلية إدارة الأعمال',
            'level': 'السنة الثانية',
            'email': 'abdulaziz.subai@university.edu.sa',
            'courses': ['إدارة الموارد البشرية', 'التمويل والاستثمار', 'نظم المعلومات', 'السلوك التنظيمي']
        },
        {
            'name': 'لينا صالح الخالدي',
            'student_id': 'STU-2024-012',
            'college': 'كلية الآداب',
            'level': 'السنة الأولى',
            'email': 'lina.khalidi@university.edu.sa',
            'courses': ['مقدمة في الأدب', 'تاريخ الحضارة', 'علم الاجتماع', 'مهارات الكتابة']
        }
    ]
    return students

def home(request):
    """عرض الصفحة الرئيسية مع بيانات الطلاب"""
    students = get_students_data()

    # حساب الإحصائيات
    students_count = len(students)

    # حساب عدد الدورات الفريدة
    all_courses = []
    for student in students:
        all_courses.extend(student['courses'])
    courses_count = len(set(all_courses))

    # حساب عدد الكليات الفريدة
    colleges = set([student['college'] for student in students])
    colleges_count = len(colleges)

    # إحصائيات إضافية
    active_courses = 45  # افتراضي
    success_rate = 92    # افتراضي

    context = {
        'students': students,
        'students_count': students_count,
        'courses_count': courses_count,
        'colleges_count': colleges_count,
        'active_courses': active_courses,
        'success_rate': success_rate,
    }

    return render(request, 'myapp/home.html', context)

def about(request):
    """عرض صفحة عن الموقع"""
    context = {
        'page_title': 'عن الموقع',
        'page_description': 'تعرف على منصة إدارة الطلاب وأهدافها التعليمية'
    }
    return render(request, 'myapp/about.html', context)

def contact(request):
    """عرض صفحة الاتصال ومعالجة النماذج"""

    if request.method == 'POST':
        # معالجة نموذج التواصل
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        student_id = request.POST.get('student_id')
        college = request.POST.get('college')

        # هنا يمكن إضافة كود لحفظ الرسالة في قاعدة البيانات
        # أو إرسالها عبر البريد الإلكتروني

        # للآن سنعرض رسالة نجاح بسيطة
        success_message = f"شكراً لك {name}، تم استلام رسالتك بنجاح. سنتواصل معك قريباً على {email}"

        context = {
            'success_message': success_message,
            'form_submitted': True
        }
        return render(request, 'myapp/contact.html', context)

    # عرض النموذج فارغ للطلبات GET
    context = {
        'page_title': 'اتصل بنا',
        'page_description': 'نحن هنا لمساعدتك - تواصل معنا في أي وقت'
    }
    return render(request, 'myapp/contact.html', context)

# دوال مساعدة إضافية (يمكن استخدامها لاحقاً)
def get_student_by_id(student_id):
    """البحث عن طالب باستخدام الرقم الجامعي"""
    students = get_students_data()
    for student in students:
        if student['student_id'] == student_id:
            return student
    return None

def get_students_by_college(college_name):
    """الحصول على قائمة الطلاب في كلية معينة"""
    students = get_students_data()
    return [student for student in students if student['college'] == college_name]

def get_available_colleges():
    """الحصول على قائمة الكليات المتاحة"""
    students = get_students_data()
    colleges = set([student['college'] for student in students])
    return sorted(list(colleges))

def get_course_statistics():
    """حساب إحصائيات الدورات"""
    students = get_students_data()
    course_count = {}

    for student in students:
        for course in student['courses']:
            if course in course_count:
                course_count[course] += 1
            else:
                course_count[course] = 1

    # ترتيب الدورات حسب عدد الطلاب المسجلين
    sorted_courses = sorted(course_count.items(), key=lambda x: x[1], reverse=True)
    return sorted_courses

def search_students(query):
    """البحث في بيانات الطلاب"""
    students = get_students_data()
    results = []

    query = query.lower()
    for student in students:
        if (query in student['name'].lower() or 
            query in student['student_id'].lower() or 
            query in student['college'].lower() or
            query in student['email'].lower()):
            results.append(student)

    return results
