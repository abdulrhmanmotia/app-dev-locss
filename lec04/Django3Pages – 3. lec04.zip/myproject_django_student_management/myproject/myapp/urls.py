from django.urls import path
from . import views

# تعريف الروابط للتطبيق
urlpatterns = [
    # الصفحة الرئيسية
    path('', views.home, name='home'),

    # صفحة عن الموقع
    path('about/', views.about, name='about'),

    # صفحة الاتصال
    path('contact/', views.contact, name='contact'),
]
