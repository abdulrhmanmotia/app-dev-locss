from django.db import models
from django.core.validators import EmailValidator

# يمكن إضافة نماذج قاعدة البيانات هنا لاحقاً
# مثال على نموذج طالب (معلق للاستخدام المستقبلي)

"""
class Student(models.Model):
    name = models.CharField(max_length=100, verbose_name="اسم الطالب")
    student_id = models.CharField(max_length=20, unique=True, verbose_name="الرقم الجامعي")
    email = models.EmailField(validators=[EmailValidator()], verbose_name="البريد الإلكتروني")
    college = models.CharField(max_length=100, verbose_name="الكلية")
    level = models.CharField(max_length=50, verbose_name="المستوى الدراسي")
    phone = models.CharField(max_length=15, blank=True, verbose_name="رقم الهاتف")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ التسجيل")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التعديل")

    class Meta:
        verbose_name = "طالب"
        verbose_name_plural = "الطلاب"
        ordering = ['name']

    def __str__(self):
        return f"{self.name} - {self.student_id}"

class Course(models.Model):
    name = models.CharField(max_length=100, verbose_name="اسم الدورة")
    code = models.CharField(max_length=10, unique=True, verbose_name="رمز الدورة")
    description = models.TextField(blank=True, verbose_name="وصف الدورة")
    credit_hours = models.IntegerField(default=3, verbose_name="الساعات المعتمدة")
    college = models.CharField(max_length=100, verbose_name="الكلية")

    class Meta:
        verbose_name = "دورة"
        verbose_name_plural = "الدورات"
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.code})"

class Enrollment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, verbose_name="الطالب")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="الدورة")
    enrolled_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ التسجيل")
    grade = models.CharField(max_length=5, blank=True, verbose_name="الدرجة")

    class Meta:
        verbose_name = "تسجيل"
        verbose_name_plural = "التسجيلات"
        unique_together = ['student', 'course']

    def __str__(self):
        return f"{self.student.name} - {self.course.name}"
"""
