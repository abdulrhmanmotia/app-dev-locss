from django.test import TestCase, Client
from django.urls import reverse

class ViewsTestCase(TestCase):
    """اختبارات للتأكد من عمل الصفحات بشكل صحيح"""

    def setUp(self):
        self.client = Client()

    def test_home_page(self):
        """اختبار الصفحة الرئيسية"""
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'منصة إدارة الطلاب')

    def test_about_page(self):
        """اختبار صفحة عن الموقع"""
        response = self.client.get(reverse('about'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'عن منصة إدارة الطلاب')

    def test_contact_page_get(self):
        """اختبار صفحة الاتصال (GET)"""
        response = self.client.get(reverse('contact'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'تواصل معنا')

    def test_contact_page_post(self):
        """اختبار صفحة الاتصال (POST)"""
        data = {
            'name': 'أحمد محمد',
            'email': 'ahmed@example.com',
            'subject': 'support',
            'message': 'رسالة اختبار'
        }
        response = self.client.post(reverse('contact'), data)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'تم استلام رسالتك بنجاح')

class UtilityFunctionsTestCase(TestCase):
    """اختبارات للدوال المساعدة"""

    def test_get_students_data(self):
        """اختبار دالة الحصول على بيانات الطلاب"""
        from myapp.views import get_students_data
        students = get_students_data()
        self.assertIsInstance(students, list)
        self.assertGreater(len(students), 0)

        # التحقق من وجود الحقول المطلوبة
        student = students[0]
        required_fields = ['name', 'student_id', 'college', 'level', 'email', 'courses']
        for field in required_fields:
            self.assertIn(field, student)
