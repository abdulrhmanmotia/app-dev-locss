from django.contrib import admin

# يمكن تسجيل النماذج هنا لإدارتها من لوحة الإدارة
# مثال (معلق للاستخدام المستقبلي):

"""
from .models import Student, Course, Enrollment

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['name', 'student_id', 'college', 'level', 'email']
    list_filter = ['college', 'level', 'created_at']
    search_fields = ['name', 'student_id', 'email']
    ordering = ['name']
    list_per_page = 20

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['name', 'code', 'college', 'credit_hours']
    list_filter = ['college', 'credit_hours']
    search_fields = ['name', 'code']
    ordering = ['name']

@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ['student', 'course', 'enrolled_at', 'grade']
    list_filter = ['course__college', 'enrolled_at', 'grade']
    search_fields = ['student__name', 'course__name']
    ordering = ['-enrolled_at']
"""
